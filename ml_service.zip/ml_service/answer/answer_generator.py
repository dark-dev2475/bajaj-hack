# ml_service/answer_generator.py

import os
import logging
from typing import Optional, List, Dict, Any

from openai import APIError
from config import OPENAI_CHAT_MODEL
from answer.answer_schema import FinalAnswer
from clients import openai_async_client


def _create_prompt(raw_query: str, search_results: List[Dict[str, Any]], query_language: str) -> str:
    """
    Builds a structured prompt for the LLM with source-aware policy clause context.
    """
    context_blocks = [
        f'Source {i + 1} (from file: {res["metadata"].get("source", "unknown")}):\n"{res["metadata"].get("text", "").strip()}"'
        for i, res in enumerate(search_results)
    ]
    context = "\n\n".join(context_blocks)

    return f"""You are an empathetic insurance claims assistant. Analyze the user's query and provided policy clauses to produce a structured JSON response.
---
Policy Clauses:
{context}
---
User Query ({query_language.upper()}): "{raw_query.strip()}"
---
Respond with a JSON object matching this schema:
{{
  "Decision": string ("Covered", "Not Covered", "Partial Coverage"),
  "Reasoning": string,
  
  "PayoutAmount": integer,
  
  "Justifications": [
    {{"source": string, "text": string, "relevance": float}}
  ]
}}
Do not include any other text.""".strip()


async def generate_answer_async(
    raw_query: str,
    search_results: List[Dict[str, Any]],
    query_language: str,
    openai_client: Optional[Any] = None
) -> Optional[FinalAnswer]:
    """
    Calls the LLM asynchronously to generate a JSON-formatted answer.
    """
    client = openai_client or openai_async_client
    if client is None:
        logging.error("OpenAI client is not initialized.")
        return None

    prompt = _create_prompt(raw_query, search_results, query_language)
    logging.info("Prompt constructed. Sending to LLM...")

    try:
        response = await client.chat.completions.create(
            model=OPENAI_CHAT_MODEL,
            messages=[{"role": "user", "content": prompt}],
        )
        content = response.choices[0].message.content
        logging.info("LLM response received. Validating JSON...")
        return FinalAnswer.model_validate_json(content)

    except APIError as api_err:
        logging.error(f"OpenAI API error: {api_err}")
    except Exception as e:
        logging.exception("Unexpected error during LLM generation.")
    
    return None
