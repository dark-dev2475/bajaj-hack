import os
import logging
import asyncio
from fastapi import FastAPI, Request, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import List
import submission_handler

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

app = FastAPI()

UPLOAD_FOLDER = 'temp_docs'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# --- Request Body Schema ---
class HackRxRequest(BaseModel):
    documents: str
    questions: List[str]

# --- The Single Endpoint for Submission ---
@app.post("/hackrx/run")
async def hackrx_run(req: HackRxRequest):
    doc_url = req.documents
    questions = req.questions

    logging.info(f"Received request for document: {doc_url} with {len(questions)} questions.")

    try:
        # Await the async handler directly in FastAPI
        answers = await submission_handler.handle_submission(doc_url, questions, UPLOAD_FOLDER)
        return JSONResponse(content={"answers": answers})

    except Exception as e:
        logging.error(f"An error occurred during submission handling: {e}")
        raise HTTPException(status_code=500, detail="An internal server error occurred.")
